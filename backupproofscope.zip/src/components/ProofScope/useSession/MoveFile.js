import React from "react";
import { CreateSession } from ".";

import axios from "axios";

export const UploadFileToServer = async (strFileName, strWrokspacePath) => {
  const sessionCreate = await CreateSession(
    // "http://azw-aac-hybrid1.np-cloud-pg.com:9090/",
    "https://proofscopenp.pg.com/",
    "admin",
    "admin"
  );
  const strSession = JSON.parse(JSON.stringify(sessionCreate)).session;
  let responseMsg = "";
  let request = null;
  const file = new File([strWrokspacePath], strFileName);
  const strProofScopeURL = "https://proofscopenp.pg.com/portal.cgi";
  try {
    const strProofScopeUploadURL = `${strProofScopeURL}?hub=upload_file&whitepaper_name=api_starter_kit&input_name=receive_file_auth&session=${strSession}`;
    const formData = new FormData();
    formData.append("file", file, strFileName);

    const response = await axios.post(strProofScopeUploadURL, formData, {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    });

    const data = response.data;
    const jsonArray = data.files;
    responseMsg = jsonArray[0];
    responseMsg = await moveFileToFolder(jsonArray, strSession, strFileName);
  } catch (exception) {
    console.log(exception);
  } finally {
    if (request != null) {
      request.close();
    }
  }

  return responseMsg;
};

const moveFileToFolder = async (strPath, strSession, strType) => {
  let strReturnPath = null;
  let strUrlParam = "https://proofscopenp.pg.com/portal.cgi";
  let os = null;
  if (strType === "Artwork File") {
    strType = "Artwork%20File";
  } else if (strType === "CIC") {
    strType = "CIC";
  }

  let sbPath =
    "cloudflow://PP_FILE_STORE/Incoming/03d94159-1681-49d7-aa4c-eae1889b5ac1/3.pdf";

  try {
    let json = {
      method: "hub.process_from_whitepaper_with_files_and_variables",
      whitepaper_name: "api_starter_kit",
      input_name: "move_file",
      files: strPath,
      variables: {
        to_file_or_folder: sbPath,
        options: {
          overwrite: true,
          create_folders: true,
          unique_name_mode: "Sequential",
          delete_enclosing_folder: true,
        },
      },
      session: strSession,
    };
    const config = {
      headers: {
        "Content-Type": "application/json",
        "Content-Language": "en-US",
      },
    };
    const response = await axios.post(
      strUrlParam,
      JSON.stringify(json),
      config
    );
    if (response.status === 200) {
      const jsonResp = response.data;
      let jsonObjArray = jsonResp.files;
      strReturnPath = jsonObjArray[0];
      console.log("strReturnPath>>>" + strReturnPath);
    }
  } catch (exception) {
    console.log(exception.message);
  }
  return strReturnPath;
};
