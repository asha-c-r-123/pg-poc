import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getUsersPega } from "../../../store/actions/UserActions";

function PegaAPI() {
  const dispatch = useDispatch();
  const [loading, setLoading] = useState(false);
  const usersList = useSelector((state) => state.users);
  const { users, error } = usersList;

  const projectData = loading ? (
    <p>Loading...</p>
  ) : error ? (
    <p>No Records...</p>
  ) : users?.length > 0 ? (
    users?.map((item, index) => {
      return (
        <div key={index}>
          <p>{item.ProjectName}</p>
        </div>
      );
    })
  ) : (
    <p>No Records...</p>
  );

  useEffect(() => {
    setLoading(true);
    dispatch(getUsersPega()).then(() => {
      setLoading(false);
    });
    // console.log(users);
  }, [dispatch]);

  return (
    <div>
      <div>Name</div>
      <div>{projectData}</div>
    </div>
  );
}
export default PegaAPI;
