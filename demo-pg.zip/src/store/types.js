export const GET_USERS = 'GET_USERS';
export const USERS_ERROR = 'USERS_ERROR'