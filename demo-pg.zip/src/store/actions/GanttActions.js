import axios from "axios";

export const getProjectDetails = (projectId) => async (dispatch) => {
  try {
    const res = await axios.get(`http://localhost:3001/data/${projectId}`);
    if (res.data === null) {
      dispatch({
        type: "GET_PROJECT_DETAILS_ERROR",
        payload: "No records found",
      });
    } else {
      dispatch({ type: "GET_PROJECT_DETAILS_SUCCESS", payload: res.data });
    }
  } catch (err) {
    console.error(err);
    dispatch({ type: "GET_PROJECT_DETAILS_ERROR", payload: err });
  }
};
