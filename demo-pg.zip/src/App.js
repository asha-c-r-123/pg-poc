import React from "react";
import { Provider } from "react-redux";
import store from "./store/store";
import { BrowserRouter } from "react-router-dom";
import "./App.scss";
import RoutesNav from "./routesNav";

function App() {
  return (
    <Provider store={store}>
      <React.StrictMode>
        <BrowserRouter>
          <RoutesNav />
        </BrowserRouter>
      </React.StrictMode>
    </Provider>
  );
}

export default App;
