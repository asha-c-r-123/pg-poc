import { useState, useEffect, useRef } from "react";
import { useDispatch } from "react-redux";
import { getTasks, deleteTask } from "../../store/actions/TaskActions";
import {
  Button,
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Form,
} from "react-bootstrap";

const AddTask = ({
  handleSubmitTask,
  isEditing,
  projectId,
  tasksInfo,
  setIsEditing,
  showForm,
  handleCancel,
}) => {
  const dispatch = useDispatch();
  const [newTask, setNewTask] = useState({
    name: "",
    start: new Date(),
    end: new Date(),
    progress: 0,
    id: "",
  });
  const formRef = useRef(null);
  const [modal, setModal] = useState(false);
  const toggle = () => setModal(!modal);
  useEffect(() => {
    setModal(showForm);
  }, [showForm]);
  useEffect(() => {
    if (isEditing) {
      setNewTask(tasksInfo);
    }
  }, [tasksInfo, isEditing]);

  const handleChange = (e) => {
    if (e.target.name === "progress") {
      setNewTask({ ...newTask, [e.target.name]: Number(e.target.value) });
    } else if (isEditing) {
      const updatedTask = { ...newTask, [e.target.name]: e.target.value };
      setNewTask(updatedTask);
    } else {
      if (e.target.name === "start" || e.target.name === "end") {
        setNewTask({ ...newTask, [e.target.name]: e.target.value });
      } else {
        setNewTask({ ...newTask, [e.target.name]: e.target.value });
      }
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    handleSubmitTask(newTask);
    // formRef.current.reset();
  };

  const handleDelete = async (e) => {
    e.preventDefault();
    if (window.confirm("Are you sure you want to delete this task?")) {
      // dispatch(deleteTask(projectId, newTask.id));
      await dispatch(deleteTask(projectId, newTask.id));
      dispatch(getTasks(projectId));
    }
  };

  let start = newTask?.start || "";
  let end = newTask?.end || "";

  // check if start and end are valid dates
  if (new Date(start).toString() !== "Invalid Date") {
    start = new Date(start).toISOString().slice(0, 10);
  } else {
    start = "";
  }

  if (new Date(end).toString() !== "Invalid Date") {
    end = new Date(end).toISOString().slice(0, 10);
  } else {
    end = "";
  }

  return (
    <>
      <div>
        <Modal show={modal} onHide={toggle} id="task-modal">
          <ModalHeader toggle={toggle}>Modal with Form</ModalHeader>
          <ModalBody>
            <Form ref={formRef}>
              <Form.Group>
                <Form.Label for="taskName">Task Name</Form.Label>
                <Form.Control
                  type="text"
                  value={newTask?.name || ""}
                  name="name"
                  required
                  onChange={handleChange}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label for="startDate"> Start Date</Form.Label>
                <Form.Control
                  type="date"
                  name="start"
                  required
                  value={start}
                  onChange={handleChange}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label for="endDate">End Date</Form.Label>
                <Form.Control
                  type="date"
                  name="end"
                  required
                  value={end}
                  onChange={handleChange}
                />
              </Form.Group>
              <Form.Group>
                <Form.Label for="progress">Progress</Form.Label>
                <Form.Control
                  type="number"
                  required
                  value={newTask?.progress || 0}
                  name="progress"
                  onChange={handleChange}
                />
              </Form.Group>
            </Form>
          </ModalBody>
          <ModalFooter>
            <Button variant="secondary cancel" onClick={handleCancel}>
              Cancel
            </Button>
            <Button color="primary" onClick={handleSubmit}>
              {isEditing ? "Update" : "Submit"}
            </Button>
          </ModalFooter>
        </Modal>
        {isEditing && <button onClick={handleDelete}>Delete Tasks</button>}
      </div>
    </>
  );
};

export default AddTask;
