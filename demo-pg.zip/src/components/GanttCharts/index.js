import React, { useState, useEffect } from "react";
import { Gantt, ViewMode } from "gantt-task-react";
import "gantt-task-react/dist/index.css";
import { useDispatch, useSelector } from "react-redux";
import { getTasks, addTask, updateTask } from "../../store/actions/TaskActions";
import { getProjectDetails } from "../../store/actions/GanttActions";
import { useParams } from "react-router-dom";
import AddTask from "./AddTask";
import { ViewSwitcher } from "./ViewSwitcher";
import AddIconImg from "../../images/plus.svg";
import { getStartEndDateForProject, formatDate } from "../../helper";
import SearchImg from "../../images/search.svg";
import sortImg from "../../images/sort.svg";
import Button from "react-bootstrap/Button";
import "./index.scss";

function GanttCharts() {
  const dispatch = useDispatch();
  const { projectDetails, loading, error } = useSelector(
    (state) => state.projectDetails
  );

  const [showForm, setShowForm] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);
  const { id } = useParams();
  const tasks = useSelector((state) => state.projecttasks);
  const [task, setTask] = useState([]);
  const [taskid, setTaskId] = useState("");
  const [isEditing, setIsEditing] = useState(false);
  const [showAddTask, setShowAddTask] = useState(true);
  const [tasksAvailable, setTasksAvailable] = useState(true);
  const [view, setView] = useState(ViewMode.Week);
  const [isChecked, setIsChecked] = React.useState(true);

  useEffect(() => {
    dispatch(getProjectDetails(id));
  }, [dispatch, id]);

  let columnWidth = 65;
  if (view === ViewMode.Year) {
    columnWidth = 350;
  } else if (view === ViewMode.Month) {
    columnWidth = 300;
  } else if (view === ViewMode.Week) {
    columnWidth = 250;
  }
  useEffect(() => {
    if (!isLoaded) {
      dispatch(getTasks(id));
      setIsLoaded(true);
    }
    setTask(tasks);
  }, [dispatch, id, isLoaded, tasks]);

  const updateGant = (task) => {
    if (!task) {
      console.error("Error: task is undefined or null");
      return;
    }
    if (!task.start || !task.end) {
      console.error("Error: task.start or task.end is undefined");
      return;
    }
    // if (isEditing) {
    //   console.log(task);
    setTaskId(task.id);
    setTask(task); // update task state variable
    setShowForm(!showForm);
    setIsEditing(true);
    setShowAddTask(false);
    // }
  };
  const handleSubmitTask = (newTask) => {
    newTask.type = "task";
    newTask.isDisabled = true;
    // console.log(isEditing);
    if (isEditing) {
      newTask.id = taskid;
      dispatch(updateTask({ ...newTask }, id)).then(() => {
        dispatch(getTasks(id));
      });
      setIsEditing(false);
      setShowForm(false);
      setShowAddTask(true);
    } else {
      newTask.id = "Task" + Math.round(Math.random() * 100000000);
      dispatch(addTask({ ...newTask, id: newTask.id }, id)).then(() =>
        dispatch(getTasks(id))
      );
      setShowForm(false);
      setShowAddTask(true);
    }
  };
  const addNewTask = () => {
    setShowForm(!showForm);
    setIsEditing(false);
    setTasksAvailable(false);
  };
  const handleCancel = () => {
    setShowForm(false);
  };
  const handleTaskChange = (task) => {
    // console.log("On date change Id:" + task.id);
    let newTasks = tasks.map((t) => (t.id === task.id ? task : t));
    if (task.project) {
      const [start, end] = getStartEndDateForProject(newTasks, task.project);
      const project =
        newTasks[newTasks.findIndex((t) => t.id === task.project)];
      if (
        project.start.getTime() !== start.getTime() ||
        project.end.getTime() !== end.getTime()
      ) {
        const changedProject = { ...project, start, end };
        newTasks = newTasks.map((t) =>
          t.id === task.project ? changedProject : t
        );
      }
    }
    setTask(newTasks);
  };
  const handleProgressChange = async (task) => {
    setTask(tasks.map((t) => (t.id === task.id ? task : t)));
    // console.log("On progress change Id:" + task.id);
  };

  const handleSelect = (task, isSelected) => {
    // console.log(task.name + " has " + (isSelected ? "selected" : "unselected"));
  };

  const handleExpanderClick = (task) => {
    setTask(tasks.map((t) => (t.id === task.id ? task : t)));
    // console.log("On expander click Id:" + task.id);
  };
  const formattedTasks =
    tasks.length > 0
      ? tasks.map((task) => {
          return {
            ...task,
            start: new Date(task.start),
            end: new Date(task.end),
          };
        })
      : null;

  return (
    <>
      <div className="task-details-actions">
        <div>
          <h4> {projectDetails.name}</h4>
          <span>{projectDetails.owener}</span>
        </div>

        <div className="search-table">
          <input
            type="search"
            placeholder="Search"
            id="searchBox"
            // value={search}
            // onChange={handleSearch}
          />
          <img src={SearchImg} alt="search" id="searchIcon" />
        </div>
        <p>
          SOS Date -
          {projectDetails.sosDate !== "" || projectDetails.sosDate !== null
            ? formatDate(projectDetails.sosDate)
            : ""}
        </p>
        <div className="search-header">
          <Button className="sort-table">
            Filter By <img src={sortImg} alt="sort" />
          </Button>
        </div>

        <div>
          <Button className="sort-table">
            {projectDetails.name} <img src={sortImg} alt="sort" />
          </Button>
        </div>
        <ViewSwitcher
          onViewModeChange={(viewMode) => setView(viewMode)}
          onViewListChange={setIsChecked}
          isChecked={isChecked}
        />
        <div className="task-actions">
          {
            <button
              onClick={addNewTask}
              type="button"
              id="add-task"
              class="btn btn-primary"
            >
              <img src={AddIconImg} alt="Add" /> Add New Task
            </button>
          }
          {showForm && (
            <AddTask
              tasksInfo={task}
              projectId={id}
              handleSubmitTask={handleSubmitTask}
              isEditing={isEditing}
              updateGant={updateGant}
              setIsEditing={setIsEditing}
              showForm={showForm}
              handleCancel={handleCancel}
            />
          )}
        </div>
      </div>
      {tasks === undefined ? (
        <p>Loading...</p>
      ) : tasks && tasks.length > 0 ? (
        <>
          <Gantt
            tasks={formattedTasks}
            viewMode={view}
            onClick={(task) => {
              updateGant(task);
            }}
            onDateChange={handleTaskChange}
            onProgressChange={handleProgressChange}
            listCellWidth={isChecked ? "100px" : ""}
            columnWidth={columnWidth}
            onSelect={handleSelect}
            onExpanderClick={handleExpanderClick}
          />
          <button></button>
        </>
      ) : (
        tasksAvailable && (
          <p className="no-tasks">
            Tasks are not available, please add new tasks
          </p>
        )
      )}
    </>
  );
}

export default GanttCharts;
