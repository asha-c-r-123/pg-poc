// Import the necessary libraries
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import PingID from "pingid-sdk";

// Import the initialization and callback actions from your Redux store
import { initializePingID, pingIDCallback } from "./redux/actions";

// Create a Hook that initializes the PingID SDK and handles the authentication process
export function usePingIDAuth() {
  const dispatch = useDispatch();
  const authState = useSelector((state) => state.auth);
  const [error, setError] = useState(null);

  useEffect(() => {
    // Initialize the PingID SDK
    PingID.init({
      clientId: "YOUR_CLIENT_ID",
      pingIdHost: "YOUR_HOST",
      callback: (response) => {
        dispatch(pingIDCallback(response));
      },
    });
    // Call the initialization action
    dispatch(initializePingID());
  }, [dispatch]);

  useEffect(() => {
    if (authState.error) {
      setError(authState.error);
    }
  }, [authState.error]);

  function startAuthentication() {
    PingID.startAuthentication();
  }

  return {
    authState,
    error,
    startAuthentication,
  };
}
